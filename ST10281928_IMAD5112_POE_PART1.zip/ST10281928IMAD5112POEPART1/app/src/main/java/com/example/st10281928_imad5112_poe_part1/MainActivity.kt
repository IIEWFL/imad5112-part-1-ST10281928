package com.example.st10281928_imad5112_poe_part1

import android.icu.math.BigDecimal
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import java.math.RoundingMode

class MainActivity : AppCompatActivity() {


    private var numberOne : TextView? = null
    private var numberTwo: TextView? = null
    private var output: TextView? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        numberOne = findViewById(R.id.firstNumber)
        numberTwo = findViewById(R.id.secondNumber)
        output = findViewById(R.id.tvAnswer)


        val add = findViewById<Button>(R.id.btnAddition)
        val minus = findViewById<Button>(R.id.btnSubtract)
        val multiply = findViewById<Button>(R.id.btnMultiply)
        val divide = findViewById<Button>(R.id.btnDivide)


        add.setOnClickListener {
            add()
        }
        minus.setOnClickListener {
            subtract()
        }
        multiply.setOnClickListener {
            multiply()
        }
        divide.setOnClickListener {
            divide()
        }
    }

    private fun add(){

        if(populated()){

            val insert1 = numberOne?.text.toString().trim().toBigDecimal()
            val insert2 = numberTwo?.text.toString().trim().toBigDecimal()
            val answer = insert1.add(insert2).toString()
            output?.text = "$insert1 + $insert2 = $answer"
        }
    }
    private fun populated(): Boolean {

        var b = true
        if (numberOne?.text.toString().trim().isEmpty()){
            numberOne?.error = "Required"
            b = false
        }
        if (numberTwo?.text.toString().trim().isEmpty()){
            numberTwo?.error = "Required"
            b = false
        }
        return b
    }
    private fun subtract(){

        if(populated()){

            val insert1 = numberOne?.text.toString().trim().toBigDecimal()
            val insert2 = numberTwo?.text.toString().trim().toBigDecimal()
            val answer = insert1.subtract(insert2).toString()
            output?.text = "$insert1 - $insert2 = $answer"
        }
    }
    private fun multiply(){

        if(populated()){

            val insert1 = numberOne?.text.toString().trim().toBigDecimal()
            val insert2 = numberTwo?.text.toString().trim().toBigDecimal()
            val answer = insert1.multiply(insert2).toString()
            output?.text = "$insert1 x $insert2 = $answer"
        }
    }
    private fun divide() {

        if (populated() && notZero()) {

            val insert1 = numberOne?.text.toString().trim().toBigDecimal()
            val insert2 = numberTwo?.text.toString().trim().toBigDecimal()
            val answer = insert1.divide(insert2, 7, RoundingMode.HALF_UP).toString()
            output?.text = "$insert1 / $insert2 = $answer"
        }
    }

    private fun notZero(): Boolean {
        var c = true

        val insert1 = numberOne?.text.toString().trim().toInt()
        val insert2 = numberTwo?.text.toString().trim().toInt()

        if (insert1 == 0 || insert2 == 0){
            output?.text = "Please enter a number bigger than zero"
            c = false
        }
        return c
    }

}